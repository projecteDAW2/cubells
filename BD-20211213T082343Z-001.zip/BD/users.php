<?php
require_once("./bd.php");
$users = mostrarUsers();
$scores = mostrarScore();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admins</title>
    <link rel="stylesheet" href="./style/style.css">
</head>

<body>
    <?php include_once("./bd.php") ?>
    <div class="muestra">
        <table>

            <tr>
                <td>ID</td>
                <td>Email</td>
                <td>Nickname</td>
                <td>Apellidos</td>
                <td>Nombre</td>
                <td>Ciclo</td>
                <td>idJuego 1</td>
                <td>idJuego 2</td>
                <td>idJuego 3</td>
                <td>idJuego 4</td>
                <td>idJuego 5</td>
            </tr>
            <?php foreach ($users as $user) { ?>
                <tr>
                    <td><?php echo $user['id']; ?></td>
                    <td><?php echo $user['email']; ?></td>
                    <td><?php echo $user['nickname']; ?></td>
                    <td><?php echo $user['apellidos']; ?></td>
                    <td><?php echo $user['nombre']; ?></td>
                    <td><?php echo $user['ciclo']; ?></td>
                    <?php foreach($scores as $score)?>
                    <td><?php if($score['idJuego']==1){echo $score['score'];}?></td>
                    <td><?php if($score['idJuego']==2){echo $score['score'];}?></td>
                    <td><?php if($score['idJuego']==3){echo $score['score'];}?></td>
                    <td><?php if($score['idJuego']==4){echo $score['score'];}?></td>
                    <td><?php if($score['idJuego']==5){echo $score['score'];}?></td>
                </tr>
            <?php } ?>
        </table>
    </div>
</body>
</html>